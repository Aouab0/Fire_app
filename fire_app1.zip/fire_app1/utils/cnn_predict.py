import numpy as np
import rasterio
from tensorflow.keras.models import load_model
import matplotlib.pyplot as plt
import os
import uuid

MODEL_PATH = 'models/fire_cnn_model.h5'
PATCH_SIZE = 16
NUM_CHANNELS = 6

def predict_burned_area(image_path):
    model = load_model(MODEL_PATH)
    with rasterio.open(image_path) as src:
        img = src.read(out_dtype='float32')
        img = np.transpose(img, (1, 2, 0))
        height, width, bands = img.shape

        pad_y = (PATCH_SIZE - height % PATCH_SIZE) % PATCH_SIZE
        pad_x = (PATCH_SIZE - width % PATCH_SIZE) % PATCH_SIZE
        img = np.pad(img, ((0, pad_y), (0, pad_x), (0, 0)), mode='constant')

        if img.shape[2] < NUM_CHANNELS:
            img = np.pad(img, ((0,0), (0,0), (0, NUM_CHANNELS - img.shape[2])), mode='constant')
        else:
            img = img[:, :, :NUM_CHANNELS]

        img = img / img.max()

        tiles, positions = [], []
        for y in range(0, img.shape[0], PATCH_SIZE):
            for x in range(0, img.shape[1], PATCH_SIZE):
                patch = img[y:y+PATCH_SIZE, x:x+PATCH_SIZE, :]
                if patch.shape[:2] == (PATCH_SIZE, PATCH_SIZE):
                    tiles.append(patch)
                    positions.append((y, x))

        tiles = np.array(tiles)
        predictions = model.predict(tiles, verbose=0)
        predicted_mask = (predictions > 0.5).astype(np.uint8).flatten()

        mask = np.zeros((img.shape[0], img.shape[1]), dtype=np.uint8)
        for (y, x), pred in zip(positions, predicted_mask):
            mask[y:y+PATCH_SIZE, x:x+PATCH_SIZE] = pred

        mask = mask[:height, :width]

        # RGB Sentinel 5-4-3
        false_rgb = img[:height, :width, [4, 3, 2]]
        false_rgb = np.clip(false_rgb * 2.5, 0, 1)

        # Overlay mask
        overlay = np.zeros((height, width, 4))
        overlay[mask == 1] = [1, 0, 0, 0.6]  # red mask

        # === Save side-by-side figure ===
        fig, axs = plt.subplots(1, 2, figsize=(12, 6))
        axs[0].imshow(false_rgb)
        axs[0].imshow(overlay)
        axs[0].set_title("🔥 Burned Area Overlay")
        axs[0].axis('off')

        axs[1].imshow(false_rgb)
        axs[1].set_title("🖼️ Original Image (8-4-3)")
        axs[1].axis('off')

        plt.tight_layout()
        output_path = f"static/result_{uuid.uuid4().hex}.png"
        plt.savefig(output_path, bbox_inches='tight')
        plt.close()

        return output_path, output_path  # we return same image for both image_path and mask_path
