import pandas as pd
import joblib
import os

MODEL_PATH = 'models/fire_rf_model.pkl'
SCALER_PATH = 'models/fire_scaler.pkl'

def predict_fire_probability(csv_path):
    model = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)

    df = pd.read_csv(csv_path, sep=';')
    colonnes_a_ignorer = ['date_debut', 'x', 'y', 'status'] if 'status' in df.columns else ['date_debut', 'x', 'y']
    X_new = df[[col for col in df.columns if col not in colonnes_a_ignorer]]
    X_scaled = scaler.transform(X_new)

    y_proba = model.predict_proba(X_scaled)
    df['proba_NoFire'] = y_proba[:, 0]
    df['proba_Fire'] = y_proba[:, 1]
    df['prediction'] = ['Fire' if p > 0.5 else 'NoFire' for p in y_proba[:, 1]]

    result_path = csv_path.replace('.csv', '_result.csv')
    df.to_csv(result_path, sep=';', index=False)
    return result_path
