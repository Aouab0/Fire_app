from flask import Flask, render_template, request, redirect, send_file
import os
from utils.cnn_predict import predict_burned_area
from utils.rf_predict import predict_fire_probability
import uuid

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict_cnn', methods=['POST'])
def predict_cnn():
    file = request.files['image']
    if file:
        path = os.path.join(UPLOAD_FOLDER, f"{uuid.uuid4()}.tif")
        file.save(path)
        image_path, mask_path = predict_burned_area(path)
        return render_template('cnn_result.html', image_path=image_path, mask_path=mask_path, show_overlay=True)

@app.route('/predict_rf', methods=['POST'])
def predict_rf():
    file = request.files['csv']
    if file:
        path = os.path.join(UPLOAD_FOLDER, f"{uuid.uuid4()}.csv")
        file.save(path)
        result_csv_path = predict_fire_probability(path)
        return send_file(result_csv_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
